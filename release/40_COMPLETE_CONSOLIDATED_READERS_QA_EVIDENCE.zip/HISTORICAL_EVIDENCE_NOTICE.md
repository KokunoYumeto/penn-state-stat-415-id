# Lingkup bukti historis

`historical-accessibility/Ace-1.4.6-report.json` adalah laporan historis yang memeriksa EPUB dengan SHA-256 `acf81b8aa62ef77cd574d45d04490ebe173539ea3f8419c5c5e1ffcea5536729`. Laporan itu **tidak** memvalidasi byte EPUB final dalam rilis ini dan tidak dijalankan ulang oleh packager. Keputusan rilis EPUB final bertumpu pada receipt build, QA deterministik, dan QA reflow statis tanpa peluncuran peramban di direktori `final-static/`.
